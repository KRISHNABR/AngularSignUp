import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/shared/user.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})

export class RegistrationComponent implements OnInit {

  constructor(public service: UserService, private toastr: ToastrService) { }

  ngOnInit() {
    this.service.formModel.reset();
  }
  onSubmit() {
    this.service.register().subscribe(
      (res: any) => {                              //succeess
        if(res.succeeded){
          this.service.formModel.reset();
          this.toastr.success('New user created!','Registeration Successfull.');
        }
        else{
          res.errors.forEach(element => {
            switch(element.code){
              case 'DuplicateUserName':
              //Username is alreday taken
              this.toastr.error('Username is already taken','Registeration failed.');
              break;
            default:
              //Registeration failed
              this.toastr.error(element.description,'Registeration failed.');
              break;
            }
          });
        }
      },                                    
      err => {                                       //error
        console.log(err);
        this.service.formModel.reset();
      }
    )
  }
}
