import { Injectable } from '@angular/core';
import {FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import {HttpClient, HttpHeaders} from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private fb: FormBuilder, private http: HttpClient)  { } //Injecting Form Builder Service to the User Service.

  readonly BaseURI ='http://localhost:53187/api';
  //Defining Form Controls
  formModel = this.fb.group({
    UserName: ['', Validators.required],
    Email: ['', Validators.email],
    FullName: [''],
    Passwords: this.fb.group({
      Password: ['', [Validators.required, Validators.minLength(4)]],
      ConfirmPassword: ['', Validators.required]},
      {validator: this.comparePasswords })
  });

  comparePasswords(fb: FormGroup){
    let confirmPwdCtrl = fb.get('ConfirmPassword');
    //passwordMismatch
    //confirmPwdCtrl.errors will be null if no validation errors.
    //confirmPwdCtrl.errors will be {required:true} if required validation error.  and {passwordMismatch: true} for mismatchig of pwd. We will only display pwdmismatch error if no errors are there previously.
    if(confirmPwdCtrl.errors == null  || 'passwordMismatch' in confirmPwdCtrl.errors){
      if(fb.get('Password').value != confirmPwdCtrl.value)
        confirmPwdCtrl.setErrors({passwordMismatch: true});
      else
        confirmPwdCtrl.setErrors(null);
    }
  }

  register(){
    var body = {
      UserName: this.formModel.value.UserName,
      Email: this.formModel.value.Email,
      FullName: this.formModel.value.FullName,
      Password: this.formModel.value.Passwords.Password
    };
    return this.http.post(this.BaseURI+'/ApplicationUser/Register',body)
  }
  login(formData){
    return this.http.post(this.BaseURI+'/ApplicationUser/Login',formData)

  }
  getUserProfile(){
    //var tokenHeader= new HttpHeaders({'Authorization':'Bearer '+ localStorage.getItem('token')});
    // return this.http.get(this.BaseURI+'/UserProfile',{headers : tokenHeader});
     return this.http.get(this.BaseURI+'/UserProfile');
  }

}
